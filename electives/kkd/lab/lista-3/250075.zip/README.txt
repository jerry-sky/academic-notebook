Lista-3
---

W celu uruchomienia programu należy wykonać `./main.py <opts> <input file> <output file>` gdzie `<opts>`:

  - `--mode` może być:
    - `encoding`
    - `decoding`
  - `--coding` może być:
    - `fib`
    - `delta`
    - `gamma`
    - `omega` *(domyślne)*
