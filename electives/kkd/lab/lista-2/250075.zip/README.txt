Lista-2
-------

W celu uruchomienia programu należy użyć:

`./main.py <--encode|--decode> <input file> <output file>`.

