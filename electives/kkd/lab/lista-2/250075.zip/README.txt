Lista-2
-------

Program używający dynamicznego kodowania Huffmana (na ocenę 4).

W celu uruchomienia programu należy użyć:

`./main.py <--encode|--decode> <input file> <output file>`.

