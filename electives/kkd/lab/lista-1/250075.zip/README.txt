Lista-1
---

W celu uruchomienia programu należy najpierw go skompilować przy pomocy `make` a następnie `./main.out <plik do otwarcia>` (przykładowe uruchomienie `./main.out pan-tadeusz.txt`).

Cały kod jest zawarty w pliku `main.cpp`.

---

Dodatkowo do zadania dołączony jest jeszcze plik `readme.md`, który jest zapisany w formacie Markdown z dodatkowymi informacjami na temat zadania. W celu wyświetlenia tego pliku można użyć np. VS Code z rozszerzeniem Markdown-all-in-one lub przekopiować zawartość pliku do edytora online `stackedit.io` (wklejanie bez formatowania).
